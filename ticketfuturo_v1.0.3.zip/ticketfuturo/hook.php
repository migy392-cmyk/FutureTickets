<?php
/**
 * Hook file para el plugin Ticket Futuro
 * Compatible con GLPI 11
 */

function plugin_ticketfuturo_install(array $params = []) {
    global $DB;

    $default_charset   = DBConnection::getDefaultCharset();
    $default_collation = DBConnection::getDefaultCollation();

    if (!$DB->tableExists('glpi_plugin_ticketfuturo_scheduledtickets')) {
        $query = "CREATE TABLE `glpi_plugin_ticketfuturo_scheduledtickets` (
            `id`                 int NOT NULL AUTO_INCREMENT,
            `name`               varchar(255) NOT NULL DEFAULT '',
            `content`            longtext,
            `scheduled_date`     datetime NOT NULL,
            `status`             tinyint NOT NULL DEFAULT 0,
            `tickets_id`         int NOT NULL DEFAULT 0,
            `type`               int NOT NULL DEFAULT 1,
            `itilcategories_id`  int NOT NULL DEFAULT 0,
            `users_id_assign`    int NOT NULL DEFAULT 0,
            `groups_id_assign`   int NOT NULL DEFAULT 0,
            `users_id_requester` int NOT NULL DEFAULT 0,
            `priority`           int NOT NULL DEFAULT 3,
            `entities_id`        int NOT NULL DEFAULT 0,
            `users_id_creator`   int NOT NULL DEFAULT 0,
            `date_creation`      datetime DEFAULT NULL,
            `date_mod`           datetime DEFAULT NULL,
            PRIMARY KEY (`id`),
            KEY `scheduled_date` (`scheduled_date`),
            KEY `status` (`status`),
            KEY `entities_id` (`entities_id`)
        ) ENGINE=InnoDB DEFAULT CHARSET={$default_charset} COLLATE={$default_collation}";

        $DB->doQueryOrDie($query, "Error creando tabla ticketfuturo");
    }

    // Registrar derechos en perfiles
    include_once(GLPI_ROOT . '/plugins/ticketfuturo/inc/profile.class.php');
    PluginTicketfuturoProfile::initProfile();
    if (isset($_SESSION['glpiactiveprofile']['id'])) {
        PluginTicketfuturoProfile::createFirstAccess($_SESSION['glpiactiveprofile']['id']);
    }

    // Registrar tarea cron
    CronTask::register(
        'PluginTicketfuturoScheduledTicket',
        'CreateScheduledTickets',
        HOUR_TIMESTAMP,
        [
            'comment' => 'Crear tickets futuros programados automaticamente',
            'mode'    => CronTask::MODE_EXTERNAL,
        ]
    );

    return true;
}

function plugin_ticketfuturo_uninstall(array $params = []) {
    global $DB;

    if ($DB->tableExists('glpi_plugin_ticketfuturo_scheduledtickets')) {
        $DB->doQueryOrDie(
            "DROP TABLE `glpi_plugin_ticketfuturo_scheduledtickets`",
            "Error eliminando tabla ticketfuturo"
        );
    }

    // Eliminar derechos de perfiles
    $DB->delete('glpi_profilerights', [
        'name' => 'plugin_ticketfuturo',
    ]);

    // Eliminar tarea cron
    $cron = new CronTask();
    $cron->deleteByCriteria(['itemtype' => 'PluginTicketfuturoScheduledTicket']);

    return true;
}
