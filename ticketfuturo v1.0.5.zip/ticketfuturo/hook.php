<?php
/**
 * Hook file - Plugin Ticket Futuro
 * Compatible GLPI 11 — usa createTable() para crear tabla nueva
 */

function plugin_ticketfuturo_install() {
    global $DB;

    $migration = new Migration(PLUGIN_TICKETFUTURO_VERSION);

    if (!$DB->tableExists('glpi_plugin_ticketfuturo_scheduledtickets')) {

        $default_charset   = DBConnection::getDefaultCharset();
        $default_collation = DBConnection::getDefaultCollation();

        $migration->createTable(
            'glpi_plugin_ticketfuturo_scheduledtickets',
            [
                'id'                 => 'INT unsigned NOT NULL AUTO_INCREMENT',
                'name'               => "VARCHAR(255) COLLATE {$default_collation} NOT NULL DEFAULT ''",
                'content'            => "LONGTEXT COLLATE {$default_collation} DEFAULT NULL",
                'scheduled_date'     => 'DATETIME NOT NULL',
                'status'             => 'TINYINT NOT NULL DEFAULT 0',
                'tickets_id'         => 'INT NOT NULL DEFAULT 0',
                'type'               => 'INT NOT NULL DEFAULT 1',
                'itilcategories_id'  => 'INT NOT NULL DEFAULT 0',
                'users_id_assign'    => 'INT NOT NULL DEFAULT 0',
                'groups_id_assign'   => 'INT NOT NULL DEFAULT 0',
                'users_id_requester' => 'INT NOT NULL DEFAULT 0',
                'priority'           => 'INT NOT NULL DEFAULT 3',
                'entities_id'        => 'INT NOT NULL DEFAULT 0',
                'users_id_creator'   => 'INT NOT NULL DEFAULT 0',
                'date_creation'      => 'DATETIME DEFAULT NULL',
                'date_mod'           => 'DATETIME DEFAULT NULL',
                'PRIMARY KEY'        => '(id)',
                'KEY scheduled_date' => '(scheduled_date)',
                'KEY status'         => '(status)',
                'KEY entities_id'    => '(entities_id)',
            ],
            "ENGINE=InnoDB DEFAULT CHARSET={$default_charset} COLLATE={$default_collation}"
        );

        $migration->executeMigration();
    }

    // Registrar derechos en perfiles
    include_once(GLPI_ROOT . '/plugins/ticketfuturo/inc/profile.class.php');
    PluginTicketfuturoProfile::initProfile();
    if (isset($_SESSION['glpiactiveprofile']['id'])) {
        PluginTicketfuturoProfile::createFirstAccess($_SESSION['glpiactiveprofile']['id']);
    }

    // Registrar tarea cron
    CronTask::register(
        'PluginTicketfuturoScheduledTicket',
        'CreateScheduledTickets',
        HOUR_TIMESTAMP,
        [
            'comment' => 'Crear tickets futuros programados automaticamente',
            'mode'    => CronTask::MODE_EXTERNAL,
        ]
    );

    return true;
}

function plugin_ticketfuturo_uninstall() {
    global $DB;

    if ($DB->tableExists('glpi_plugin_ticketfuturo_scheduledtickets')) {
        $migration = new Migration(PLUGIN_TICKETFUTURO_VERSION);
        $migration->dropTable('glpi_plugin_ticketfuturo_scheduledtickets');
        $migration->executeMigration();
    }

    $profileRight = new ProfileRight();
    $profileRight->deleteByCriteria(['name' => 'plugin_ticketfuturo']);

    $cron = new CronTask();
    $cron->deleteByCriteria(['itemtype' => 'PluginTicketfuturoScheduledTicket']);

    return true;
}
