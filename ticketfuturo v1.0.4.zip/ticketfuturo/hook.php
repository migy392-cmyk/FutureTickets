<?php
/**
 * Hook file para el plugin Ticket Futuro
 * Compatible con GLPI 11
 * Firma sin parámetros según documentación oficial GLPI
 */

function plugin_ticketfuturo_install() {
    global $DB;

    $default_charset   = DBConnection::getDefaultCharset();
    $default_collation = DBConnection::getDefaultCollation();

    // Instanciar Migration correctamente (según doc oficial GLPI)
    $migration = new Migration(PLUGIN_TICKETFUTURO_VERSION);

    if (!$DB->tableExists('glpi_plugin_ticketfuturo_scheduledtickets')) {
        $migration->addField('glpi_plugin_ticketfuturo_scheduledtickets', 'id',                 'autoincrement');
        $migration->addField('glpi_plugin_ticketfuturo_scheduledtickets', 'name',               'string',   ['value' => '']);
        $migration->addField('glpi_plugin_ticketfuturo_scheduledtickets', 'content',            'text');
        $migration->addField('glpi_plugin_ticketfuturo_scheduledtickets', 'scheduled_date',     'datetime', ['nodefault' => true]);
        $migration->addField('glpi_plugin_ticketfuturo_scheduledtickets', 'status',             'tinyint',  ['value' => 0]);
        $migration->addField('glpi_plugin_ticketfuturo_scheduledtickets', 'tickets_id',         'integer',  ['value' => 0]);
        $migration->addField('glpi_plugin_ticketfuturo_scheduledtickets', 'type',               'integer',  ['value' => 1]);
        $migration->addField('glpi_plugin_ticketfuturo_scheduledtickets', 'itilcategories_id',  'integer',  ['value' => 0]);
        $migration->addField('glpi_plugin_ticketfuturo_scheduledtickets', 'users_id_assign',    'integer',  ['value' => 0]);
        $migration->addField('glpi_plugin_ticketfuturo_scheduledtickets', 'groups_id_assign',   'integer',  ['value' => 0]);
        $migration->addField('glpi_plugin_ticketfuturo_scheduledtickets', 'users_id_requester', 'integer',  ['value' => 0]);
        $migration->addField('glpi_plugin_ticketfuturo_scheduledtickets', 'priority',           'integer',  ['value' => 3]);
        $migration->addField('glpi_plugin_ticketfuturo_scheduledtickets', 'entities_id',        'integer',  ['value' => 0]);
        $migration->addField('glpi_plugin_ticketfuturo_scheduledtickets', 'users_id_creator',   'integer',  ['value' => 0]);
        $migration->addField('glpi_plugin_ticketfuturo_scheduledtickets', 'date_creation',      'datetime');
        $migration->addField('glpi_plugin_ticketfuturo_scheduledtickets', 'date_mod',           'datetime');
        $migration->addKey('glpi_plugin_ticketfuturo_scheduledtickets',   'scheduled_date');
        $migration->addKey('glpi_plugin_ticketfuturo_scheduledtickets',   'status');
        $migration->addKey('glpi_plugin_ticketfuturo_scheduledtickets',   'entities_id');
        $migration->executeMigration();
    }

    // Registrar derechos en perfiles
    include_once(GLPI_ROOT . '/plugins/ticketfuturo/inc/profile.class.php');
    PluginTicketfuturoProfile::initProfile();
    if (isset($_SESSION['glpiactiveprofile']['id'])) {
        PluginTicketfuturoProfile::createFirstAccess($_SESSION['glpiactiveprofile']['id']);
    }

    // Registrar tarea cron
    CronTask::register(
        'PluginTicketfuturoScheduledTicket',
        'CreateScheduledTickets',
        HOUR_TIMESTAMP,
        [
            'comment' => 'Crear tickets futuros programados automaticamente',
            'mode'    => CronTask::MODE_EXTERNAL,
        ]
    );

    return true;
}

function plugin_ticketfuturo_uninstall() {
    $migration = new Migration(PLUGIN_TICKETFUTURO_VERSION);
    $migration->dropTable('glpi_plugin_ticketfuturo_scheduledtickets');
    $migration->executeMigration();

    $profileRight = new ProfileRight();
    $profileRight->deleteByCriteria(['name' => 'plugin_ticketfuturo']);

    $cron = new CronTask();
    $cron->deleteByCriteria(['itemtype' => 'PluginTicketfuturoScheduledTicket']);

    return true;
}
