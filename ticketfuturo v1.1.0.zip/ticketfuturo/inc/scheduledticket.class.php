<?php
if (!defined('GLPI_ROOT')) die("No direct access");

use Glpi\Application\View\TemplateRenderer;

class PluginTicketfuturoScheduledTicket extends CommonDBTM {
    static $rightname = 'plugin_ticketfuturo';

    public static function getTypeName($nb = 0) {
        return 'Ticket Futuro';
    }

    public static function getMenuName() {
        return 'Tickets Futuros';
    }

    public static function getFormURL($full = true) {
        return Plugin::getWebDir('ticketfuturo', $full) . '/front/scheduledticket.form.php';
    }

    public static function getSearchURL($full = true) {
        return Plugin::getWebDir('ticketfuturo', $full) . '/front/scheduledticket.php';
    }

    public static function getMenuContent() {
        $menu = [];
        if (self::canView()) {
            $menu['title'] = self::getMenuName();
            $menu['page']  = Plugin::getWebDir('ticketfuturo') . '/front/scheduledticket.php';
            $menu['icon']  = 'ti ti-clock-plus';
            $menu['options']['scheduledticket']['title']           = self::getMenuName();
            $menu['options']['scheduledticket']['page']            = Plugin::getWebDir('ticketfuturo') . '/front/scheduledticket.php';
            $menu['options']['scheduledticket']['links']['search'] = Plugin::getWebDir('ticketfuturo') . '/front/scheduledticket.php';
            if (self::canCreate()) {
                $menu['options']['scheduledticket']['links']['add'] = Plugin::getWebDir('ticketfuturo') . '/front/scheduledticket.form.php';
            }
        }
        return $menu;
    }

    public function defineTabs($options = []) {
        $ong = [];
        $this->addDefaultFormTab($ong);
        return $ong;
    }

    public function rawSearchOptions() {
        $tab = [];
        $tab[] = ['id' => 'common', 'name' => self::getTypeName(1)];
        $tab[] = ['id' => '1', 'table' => $this->getTable(), 'field' => 'name',           'name' => 'Título',           'datatype' => 'itemlink', 'massiveaction' => false];
        $tab[] = ['id' => '2', 'table' => $this->getTable(), 'field' => 'scheduled_date', 'name' => 'Fecha programada', 'datatype' => 'datetime',  'massiveaction' => false];
        $tab[] = ['id' => '3', 'table' => $this->getTable(), 'field' => 'status',         'name' => 'Estado',           'datatype' => 'specific',  'massiveaction' => false];
        $tab[] = ['id' => '4', 'table' => $this->getTable(), 'field' => 'priority',       'name' => 'Prioridad',        'datatype' => 'specific',  'massiveaction' => false];
        $tab[] = ['id' => '5', 'table' => 'glpi_itilcategories', 'field' => 'completename', 'name' => 'Categoría',      'datatype' => 'dropdown',  'foreignkey' => 'itilcategories_id'];
        $tab[] = ['id' => '6', 'table' => $this->getTable(), 'field' => 'type',           'name' => 'Tipo',             'datatype' => 'specific'];
        return $tab;
    }

    public function showForm($ID, $options = []) {
        $this->initForm($ID, $options);
        $item     = $this;
        $disabled = ($item->fields['status'] ?? 0) != 0;
        $isNew    = ($ID <= 0);

        echo "<div class='container-fluid mt-3'>";

        // Alertas de estado
        if (!$isNew) {
            if ($item->fields['status'] == 1) {
                echo "<div class='alert alert-success mb-3'><i class='ti ti-check me-2'></i>Este ticket futuro ya fue creado. Ticket generado: <a href='" . GLPI_URL . "/front/ticket.form.php?id={$item->fields['tickets_id']}' target='_blank'>#{$item->fields['tickets_id']}</a></div>";
            } elseif ($item->fields['status'] == 2) {
                echo "<div class='alert alert-danger mb-3'><i class='ti ti-x me-2'></i>Este ticket futuro fue cancelado.</div>";
            }
        }

        $formId = 'form_ticketfuturo_' . ($ID > 0 ? $ID : 'new');
        echo "<form method='POST' action='" . Plugin::getWebDir('ticketfuturo') . "/front/scheduledticket.form.php' id='{$formId}' data-track-changes='true'>";
        echo Html::hidden('_glpi_csrf_token', ['value' => Session::getNewCSRFToken()]);
        if (!$isNew) echo "<input type='hidden' name='id' value='{$ID}'>";

        echo "<div class='row g-3'>";

        // Título
        echo "<div class='col-12'>";
        echo "<label class='form-label fw-bold'>Título <span class='text-danger'>*</span></label>";
        $nameVal = htmlspecialchars($item->fields['name'] ?? '', ENT_QUOTES);
        if ($disabled) {
            echo "<input type='text' class='form-control' name='name' value='{$nameVal}' disabled required>";
        } else {
            echo "<input type='text' class='form-control' name='name' value='{$nameVal}' required autocomplete='off'>";
        }
        echo "</div>";

        // Fecha programada
        echo "<div class='col-md-6'>";
        echo "<label class='form-label fw-bold'>Fecha programada de creación <span class='text-danger'>*</span></label>";
        $dateVal = !empty($item->fields['scheduled_date']) ? date('Y-m-d\TH:i', strtotime($item->fields['scheduled_date'])) : '';
        if ($disabled) {
            echo "<input type='datetime-local' class='form-control' name='scheduled_date' value='{$dateVal}' disabled required>";
        } else {
            echo "<input type='datetime-local' class='form-control' name='scheduled_date' value='{$dateVal}' required autocomplete='off'>";
        }
        echo "<div class='form-text'>El ticket se creará automáticamente en esta fecha.</div>";
        echo "</div>";

        // Tipo
        echo "<div class='col-md-6'>";
        echo "<label class='form-label fw-bold'>Tipo</label>";
        echo "<select class='form-select' name='type' " . ($disabled ? 'disabled' : '') . ">";
        echo "<option value='1'" . (($item->fields['type'] ?? 1) == 1 ? ' selected' : '') . ">Incidencia</option>";
        echo "<option value='2'" . (($item->fields['type'] ?? 1) == 2 ? ' selected' : '') . ">Petición</option>";
        echo "</select></div>";

        // Prioridad
        echo "<div class='col-md-6'>";
        echo "<label class='form-label fw-bold'>Prioridad</label>";
        echo "<select class='form-select' name='priority' " . ($disabled ? 'disabled' : '') . ">";
        $priorities = [1 => 'Muy baja', 2 => 'Baja', 3 => 'Media', 4 => 'Alta', 5 => 'Muy alta', 6 => 'Urgente'];
        foreach ($priorities as $val => $label) {
            $sel = (($item->fields['priority'] ?? 3) == $val) ? ' selected' : '';
            echo "<option value='{$val}'{$sel}>{$label}</option>";
        }
        echo "</select></div>";

        // Categoría
        echo "<div class='col-md-6'>";
        echo "<label class='form-label fw-bold'>Categoría</label>";
        ITILCategory::dropdown([
            'name'     => 'itilcategories_id',
            'value'    => $item->fields['itilcategories_id'] ?? 0,
            'disabled' => $disabled,
        ]);
        echo "</div>";

        // Solicitante
        echo "<div class='col-md-6'>";
        echo "<label class='form-label fw-bold'>Solicitante</label>";
        User::dropdown([
            'name'     => 'users_id_requester',
            'value'    => $item->fields['users_id_requester'] ?? 0,
            'disabled' => $disabled,
        ]);
        echo "</div>";

        // Técnico asignado
        echo "<div class='col-md-6'>";
        echo "<label class='form-label fw-bold'>Asignado a (técnico)</label>";
        User::dropdown([
            'name'     => 'users_id_assign',
            'value'    => $item->fields['users_id_assign'] ?? 0,
            'disabled' => $disabled,
            'right'    => 'own_ticket',
        ]);
        echo "</div>";

        // Grupo asignado
        echo "<div class='col-md-6'>";
        echo "<label class='form-label fw-bold'>Grupo asignado</label>";
        Group::dropdown([
            'name'     => 'groups_id_assign',
            'value'    => $item->fields['groups_id_assign'] ?? 0,
            'disabled' => $disabled,
        ]);
        echo "</div>";

        // Descripción
        echo "<div class='col-12'>";
        echo "<label class='form-label fw-bold'>Descripción</label>";
        $contentVal = htmlspecialchars($item->fields['content'] ?? '', ENT_QUOTES);
        if ($disabled) {
            echo "<textarea class='form-control' name='content' rows='6' disabled>{$contentVal}</textarea>";
        } else {
            echo "<textarea class='form-control' name='content' rows='6' autocomplete='off'>{$contentVal}</textarea>";
        }
        echo "</div>";

        echo "</div>"; // row

        // Estado (solo si ya existe)
        if (!$isNew) {
            $statusLabels = [0 => 'Pendiente', 1 => 'Creado', 2 => 'Cancelado'];
            $statusColors = [0 => 'warning',   1 => 'success', 2 => 'danger'];
            $st = $item->fields['status'];
            echo "<hr><div class='row mt-2'><div class='col-md-3'>";
            echo "<label class='form-label fw-bold'>Estado</label><br>";
            echo "<span class='badge bg-{$statusColors[$st]}'>{$statusLabels[$st]}</span>";
            echo "</div></div>";
        }

        // Botones
        echo "<div class='d-flex gap-2 mt-3'>";
        if ($isNew) {
            echo "<button type='submit' name='add' class='btn btn-primary'><i class='ti ti-plus me-1'></i>Crear ticket futuro</button>";
        } elseif (!$disabled) {
            echo "<button type='submit' name='update' class='btn btn-primary'><i class='ti ti-device-floppy me-1'></i>Guardar</button>";
            echo "<button type='submit' name='cancel' class='btn btn-outline-danger'><i class='ti ti-ban me-1'></i>Cancelar ticket futuro</button>";
        }
        echo "<a href='" . Plugin::getWebDir('ticketfuturo') . "/front/scheduledticket.php' class='btn btn-outline-secondary'>Volver</a>";
        echo "</div>";

        echo "</form>";
        echo "</div>";

        return true;
    }

    public function prepareInputForAdd($input) {
        if (isset($input['scheduled_date'])) {
            $input['scheduled_date'] = str_replace('T', ' ', $input['scheduled_date']);
        }
        $input['date_creation']    = date('Y-m-d H:i:s');
        $input['date_mod']         = date('Y-m-d H:i:s');
        $input['users_id_creator'] = Session::getLoginUserID();
        $input['entities_id']      = $_SESSION['glpiactive_entity'] ?? 0;
        $input['status']           = 0;
        if (empty($input['scheduled_date'])) {
            Session::addMessageAfterRedirect('La fecha programada es obligatoria.', false, ERROR);
            return false;
        }
        if (strtotime($input['scheduled_date']) <= time()) {
            Session::addMessageAfterRedirect('La fecha programada debe ser futura.', false, ERROR);
            return false;
        }
        return $input;
    }

    public function prepareInputForUpdate($input) {
        if (isset($input['scheduled_date'])) {
            $input['scheduled_date'] = str_replace('T', ' ', $input['scheduled_date']);
        }
        $input['date_mod'] = date('Y-m-d H:i:s');
        return $input;
    }

    public function cancelScheduledTicket($id) {
        return $this->update(['id' => $id, 'status' => 2, 'date_mod' => date('Y-m-d H:i:s')]);
    }

    public static function cronCreateScheduledTickets($task) {
        global $DB;
        $now = date('Y-m-d H:i:s');
        $created = 0;
        $errors  = 0;

        $iterator = $DB->request([
            'FROM'  => 'glpi_plugin_ticketfuturo_scheduledtickets',
            'WHERE' => ['status' => 0, 'scheduled_date' => ['<=', $now]],
        ]);

        foreach ($iterator as $row) {
            $ticket    = new Ticket();
            $ticket_id = $ticket->add([
                'name'                => $row['name'],
                'content'             => $row['content'] ?? '',
                'type'                => $row['type'],
                'itilcategories_id'   => $row['itilcategories_id'],
                'priority'            => $row['priority'],
                'entities_id'         => $row['entities_id'],
                '_users_id_assign'    => $row['users_id_assign'],
                '_groups_id_assign'   => $row['groups_id_assign'],
                '_users_id_requester' => $row['users_id_requester'] ?: 0,
                'status'              => Ticket::INCOMING,
            ]);

            $scheduled = new self();
            if ($ticket_id) {
                $scheduled->update(['id' => $row['id'], 'status' => 1, 'tickets_id' => $ticket_id, 'date_mod' => date('Y-m-d H:i:s')]);
                self::sendCreationNotification($row, $ticket_id);
                $created++;
                $task->addVolume(1);
                $task->log("Ticket futuro ID {$row['id']} creado como Ticket #{$ticket_id}");
            } else {
                $errors++;
                $task->log("Error al crear ticket futuro ID {$row['id']}");
            }
        }
        return ($errors > 0) ? -1 : ($created > 0 ? 1 : 0);
    }

    public static function cronInfo($name) {
        return ['description' => 'Crear tickets programados cuando llegue su fecha'];
    }

    protected static function sendCreationNotification($scheduledData, $ticket_id) {
        $user = new User();
        if (!$user->getFromDB($scheduledData['users_id_creator'])) return;
        $email = $user->getDefaultEmail();
        if (empty($email)) return;
        $mmail = new GLPIMailer();
        $mmail->AddAddress($email, $user->getFriendlyName());
        $mmail->SetFrom(defined('GLPI_NOREPLY_EMAIL') ? GLPI_NOREPLY_EMAIL : 'noreply@glpi.local');
        $mmail->Subject = "[GLPI] Ticket Futuro creado: {$scheduledData['name']} (#{$ticket_id})";
        $mmail->Body    = "El ticket futuro '{$scheduledData['name']}' ha sido creado automaticamente.\n\nTicket ID: #{$ticket_id}\nFecha: " . date('d/m/Y H:i');
        $mmail->IsHTML(false);
        try { $mmail->Send(); } catch (Exception $e) {}
    }
}
