<?php
/**
 * Hook file para el plugin Ticket Futuro
 */

function plugin_ticketfuturo_install(Migration $migration = null) {
    global $DB;

    $default_charset   = DBConnection::getDefaultCharset();
    $default_collation = DBConnection::getDefaultCollation();

    if (!$DB->tableExists('glpi_plugin_ticketfuturo_scheduledtickets')) {
        $query = "CREATE TABLE `glpi_plugin_ticketfuturo_scheduledtickets` (
            `id`                INT(11) NOT NULL AUTO_INCREMENT,
            `name`              VARCHAR(255) NOT NULL DEFAULT '',
            `content`           TEXT,
            `scheduled_date`    DATETIME NOT NULL,
            `status`            TINYINT(1) NOT NULL DEFAULT 0 COMMENT '0=pendiente,1=creado,2=cancelado',
            `tickets_id`        INT(11) NOT NULL DEFAULT 0 COMMENT 'ID del ticket creado',
            `type`              INT(11) NOT NULL DEFAULT 1 COMMENT '1=Incidencia,2=Peticion',
            `itilcategories_id` INT(11) NOT NULL DEFAULT 0,
            `users_id_assign`   INT(11) NOT NULL DEFAULT 0,
            `groups_id_assign`  INT(11) NOT NULL DEFAULT 0,
            `users_id_requester`INT(11) NOT NULL DEFAULT 0,
            `priority`          INT(11) NOT NULL DEFAULT 3,
            `entities_id`       INT(11) NOT NULL DEFAULT 0,
            `users_id_creator`  INT(11) NOT NULL DEFAULT 0,
            `date_creation`     DATETIME DEFAULT NULL,
            `date_mod`          DATETIME DEFAULT NULL,
            PRIMARY KEY (`id`),
            KEY `scheduled_date` (`scheduled_date`),
            KEY `status` (`status`),
            KEY `entities_id` (`entities_id`)
        ) ENGINE=InnoDB DEFAULT CHARSET={$default_charset} COLLATE={$default_collation}";
        $DB->doQuery($query);
    }

    // Insertar derecho en profile
    include_once(GLPI_ROOT . '/plugins/ticketfuturo/inc/profile.class.php');
    PluginTicketfuturoProfile::initProfile();
    PluginTicketfuturoProfile::createFirstAccess($_SESSION['glpiactiveprofile']['id']);

    // Registrar tarea cron
    CronTask::register(
        'PluginTicketfuturoScheduledTicket',
        'CreateScheduledTickets',
        HOUR_TIMESTAMP,
        [
            'comment' => 'Crear tickets futuros programados automáticamente',
            'mode'    => CronTask::MODE_EXTERNAL,
        ]
    );

    return true;
}

function plugin_ticketfuturo_uninstall() {
    global $DB;

    $tables = [
        'glpi_plugin_ticketfuturo_scheduledtickets',
    ];

    foreach ($tables as $table) {
        $DB->doQuery("DROP TABLE IF EXISTS `$table`");
    }

    // Eliminar derechos de perfiles
    $DB->delete('glpi_profilerights', [
        'name' => ['LIKE', 'plugin_ticketfuturo%'],
    ]);

    // Eliminar tarea cron
    $cron = new CronTask();
    $cron->deleteByCriteria(['itemtype' => 'PluginTicketfuturoScheduledTicket']);

    return true;
}
