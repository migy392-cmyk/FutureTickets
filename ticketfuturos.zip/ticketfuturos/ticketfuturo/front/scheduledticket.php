<?php
/**
 * Lista de tickets futuros
 */

include('../../../inc/includes.php');

Session::checkRight('plugin_ticketfuturo', READ);

Html::header(
    __('Tickets Futuros', 'ticketfuturo'),
    $_SERVER['PHP_SELF'],
    'admin',
    'PluginTicketfuturoScheduledTicket'
);

Search::show('PluginTicketfuturoScheduledTicket');

Html::footer();
