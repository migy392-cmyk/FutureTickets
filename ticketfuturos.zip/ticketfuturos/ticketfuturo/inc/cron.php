<?php
/**
 * Registro de tareas cron para el plugin Ticket Futuro
 */

if (!defined('GLPI_ROOT')) {
    die("Sorry. You can't access this file directly");
}

// Registrar cron task al instalar
function plugin_ticketfuturo_registerCron() {
    CronTask::register(
        'PluginTicketfuturoScheduledTicket',
        'CreateScheduledTickets',
        HOUR_TIMESTAMP,
        [
            'comment' => 'Crear tickets futuros programados',
            'mode'    => CronTask::MODE_EXTERNAL,
        ]
    );
}

// Llamado desde hook.php install
function plugin_ticketfuturo_install_cron() {
    plugin_ticketfuturo_registerCron();
}
