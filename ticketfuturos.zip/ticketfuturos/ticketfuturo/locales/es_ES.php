<?php
/**
 * Traducciones al español para el plugin Ticket Futuro
 */

$lang['ticketfuturo'] = [
    'Ticket Futuro'                                    => 'Ticket Futuro',
    'Tickets Futuros'                                  => 'Tickets Futuros',
    'Datos del Ticket Futuro'                          => 'Datos del Ticket Futuro',
    'Título'                                           => 'Título',
    'Descripción'                                      => 'Descripción',
    'Categoría'                                        => 'Categoría',
    'Prioridad'                                        => 'Prioridad',
    'Tipo'                                             => 'Tipo',
    'Solicitante'                                      => 'Solicitante',
    'Asignado a (técnico)'                             => 'Asignado a (técnico)',
    'Grupo asignado'                                   => 'Grupo asignado',
    'Fecha programada de creación'                     => 'Fecha programada de creación',
    'Estado'                                           => 'Estado',
    'Pendiente'                                        => 'Pendiente',
    'Creado'                                           => 'Creado',
    'Cancelado'                                        => 'Cancelado',
    'Fecha programada'                                 => 'Fecha programada',
    'Información del sistema'                          => 'Información del sistema',
    'Ticket generado'                                  => 'Ticket generado',
    'Cancelar ticket futuro'                           => 'Cancelar ticket futuro',
    'Ticket futuro cancelado correctamente.'           => 'Ticket futuro cancelado correctamente.',
    'La fecha programada es obligatoria.'              => 'La fecha programada es obligatoria.',
    'La fecha programada debe ser futura.'             => 'La fecha programada debe ser futura.',
    'Gestión de Tickets Futuros'                       => 'Gestión de Tickets Futuros',
    'Plugin Ticket Futuro'                             => 'Plugin Ticket Futuro',
    'El ticket futuro \'%s\' ha sido creado automáticamente.\n\nTicket ID: #%d\nFecha de creación: %s\n\nAccede a GLPI para ver el ticket.' => 'El ticket futuro \'%s\' ha sido creado automáticamente.\n\nTicket ID: #%d\nFecha de creación: %s\n\nAccede a GLPI para ver el ticket.',
    '[GLPI] Ticket Futuro creado: %s (#%d)'            => '[GLPI] Ticket Futuro creado: %s (#%d)',
    'Crear tickets programados cuando llegue su fecha' => 'Crear tickets programados cuando llegue su fecha',
    'El ticket se creará automáticamente en esta fecha y hora.' => 'El ticket se creará automáticamente en esta fecha y hora.',
    'Este ticket futuro ya fue creado. Ticket generado: #' => 'Este ticket futuro ya fue creado. Ticket generado: #',
    'Este ticket futuro fue cancelado.'                => 'Este ticket futuro fue cancelado.',
];
