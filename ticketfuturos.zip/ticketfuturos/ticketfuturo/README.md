# Plugin Ticket Futuro para GLPI 11

## Descripción
Plugin para programar tickets que se crearán automáticamente en una fecha y hora futura.

## Requisitos
- GLPI >= 11.0.0
- PHP >= 8.1

## Instalación
1. Descomprime el contenido del zip en `/glpi/plugins/ticketfuturo/`
2. Ve a **Configuración > Plugins** en GLPI
3. Busca "Ticket Futuro" y haz clic en **Instalar**
4. Luego haz clic en **Activar**

## Configuración de permisos
1. Ve a **Administración > Perfiles**
2. Selecciona el perfil que debe tener acceso
3. En la pestaña correspondiente, asigna los derechos del plugin

## Uso
1. Ve a **Administración > Tickets Futuros**
2. Crea un nuevo ticket futuro con:
   - Título y descripción
   - Fecha y hora de creación programada
   - Tipo, categoría, prioridad
   - Solicitante, técnico asignado y grupo
3. Cuando llegue la fecha, el cron lo creará automáticamente

## Cron
El plugin registra una tarea cron llamada `CreateScheduledTickets` que se ejecuta cada hora.

Para ejecutarlo manualmente:
```bash
php /var/www/glpi/front/cron.php CreateScheduledTickets
```

O configura el cron del sistema:
```
*/30 * * * * www-data php /var/www/glpi/front/cron.php CreateScheduledTickets > /dev/null 2>&1
```

## Notificaciones
Al crearse el ticket, se envía un email al usuario que creó el ticket futuro.

## Estructura de archivos
```
ticketfuturo/
├── setup.php              # Configuración principal del plugin
├── hook.php               # Instalación/desinstalación
├── ticketfuturo.css       # Estilos
├── front/
│   ├── scheduledticket.php        # Lista de tickets futuros
│   └── scheduledticket.form.php   # Formulario
├── inc/
│   ├── scheduledticket.class.php  # Clase principal + cron
│   ├── profile.class.php          # Gestión de perfiles
│   └── cron.php                   # Helpers de cron
├── locales/
│   └── es_ES.php          # Traducciones español
└── templates/
    └── scheduledticket.form.html.twig  # Plantilla Twig del formulario
```
