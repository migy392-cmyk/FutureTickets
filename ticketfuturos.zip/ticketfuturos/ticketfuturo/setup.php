<?php
/**
 * Plugin Ticket Futuro para GLPI 11
 */

define('PLUGIN_TICKETFUTURO_VERSION', '1.0.0');
define('PLUGIN_TICKETFUTURO_MIN_GLPI', '11.0.0');
define('PLUGIN_TICKETFUTURO_MAX_GLPI', '11.99.99');

function plugin_init_ticketfuturo() {
    global $PLUGIN_HOOKS;

    $PLUGIN_HOOKS['csrf_compliant']['ticketfuturo'] = true;

    if (Session::haveRight('plugin_ticketfuturo', READ)) {
        $PLUGIN_HOOKS['menu_toadd']['ticketfuturo'] = [
            'admin' => 'PluginTicketfuturoScheduledTicket'
        ];
    }

    $PLUGIN_HOOKS['add_css']['ticketfuturo'] = 'ticketfuturo.css';
}

function plugin_version_ticketfuturo() {
    return [
        'name'           => 'Ticket Futuro',
        'version'        => PLUGIN_TICKETFUTURO_VERSION,
        'author'         => 'GLPI Plugin',
        'license'        => 'GPL v2+',
        'homepage'       => '',
        'requirements'   => [
            'glpi' => [
                'min' => PLUGIN_TICKETFUTURO_MIN_GLPI,
                'max' => PLUGIN_TICKETFUTURO_MAX_GLPI,
            ],
            'php'  => [
                'min' => '8.1',
            ],
        ],
    ];
}

function plugin_ticketfuturo_check_prerequisites() {
    if (version_compare(GLPI_VERSION, PLUGIN_TICKETFUTURO_MIN_GLPI, 'lt')
        || version_compare(GLPI_VERSION, PLUGIN_TICKETFUTURO_MAX_GLPI, 'gt')) {
        echo "Este plugin requiere GLPI >= " . PLUGIN_TICKETFUTURO_MIN_GLPI;
        return false;
    }
    return true;
}

function plugin_ticketfuturo_check_config() {
    return true;
}
