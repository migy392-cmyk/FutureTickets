<?php
/**
 * Gestión de perfiles y derechos
 */

if (!defined('GLPI_ROOT')) {
    die("Sorry. You can't access this file directly");
}

class PluginTicketfuturoProfile extends CommonDBTM {

    static $rightname = 'profile';

    public static function initProfile() {
        global $DB;

        $rights = [
            'plugin_ticketfuturo' => [
                'name'    => 'plugin_ticketfuturo',
                'comment' => 'Plugin Ticket Futuro',
            ],
        ];

        foreach ($rights as $right) {
            if (!countElementsInTable('glpi_profilerights', ['name' => $right['name']])) {
                ProfileRight::addProfileRights([$right['name']]);
            }
        }
    }

    public static function createFirstAccess($profiles_id) {
        include_once(GLPI_ROOT . '/plugins/ticketfuturo/inc/profile.class.php');

        self::addDefaultProfileInfos(
            $profiles_id,
            ['plugin_ticketfuturo' => READ | UPDATE | CREATE | DELETE | PURGE]
        );
    }

    public static function addDefaultProfileInfos($profiles_id, $rights, $drop = false) {
        $profileRight = new ProfileRight();

        foreach ($rights as $right => $value) {
            if ($drop) {
                $profileRight->deleteByCriteria(['profiles_id' => $profiles_id, 'name' => $right]);
            }

            if (!countElementsInTable('glpi_profilerights', ['profiles_id' => $profiles_id, 'name' => $right])) {
                $profileRight->add([
                    'profiles_id' => $profiles_id,
                    'name'        => $right,
                    'rights'      => $value,
                ]);
            } else {
                $profileRight->update([
                    'id'          => $profileRight->getFromDBByCrit(['profiles_id' => $profiles_id, 'name' => $right]) ? $profileRight->fields['id'] : 0,
                    'profiles_id' => $profiles_id,
                    'name'        => $right,
                    'rights'      => $value,
                ]);
            }
        }
    }

    public static function showForProfile(array $options = []) {
        $profile = new Profile();

        echo "<div class='firstbloc'>";
        echo "<table class='tab_cadre_fixehov'>";
        echo "<tr><th colspan='4'>" . __('Plugin Ticket Futuro', 'ticketfuturo') . "</th></tr>";
        echo "<tr class='tab_bg_2'>";
        echo "<td>" . __('Gestión de Tickets Futuros', 'ticketfuturo') . "</td>";
        echo "<td>";
        $profile->showRightsChoiceMatrix(
            [
                'plugin_ticketfuturo' => __('Tickets Futuros', 'ticketfuturo'),
            ],
            [
                'canedit'       => $options['canedit'] ?? false,
                'default_class' => 'tab_bg_2',
                'title'         => '',
            ]
        );
        echo "</td>";
        echo "</tr>";
        echo "</table></div>";
    }

    public static function removeRightsFromSession() {
        if (isset($_SESSION['glpiactiveprofile'])) {
            foreach (['plugin_ticketfuturo'] as $right) {
                unset($_SESSION['glpiactiveprofile'][$right]);
            }
        }
    }

    public static function getRight($right = 'plugin_ticketfuturo') {
        return Session::haveRight($right, READ);
    }
}
