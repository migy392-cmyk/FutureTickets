<?php
/**
 * Hook file - Plugin Ticket Futuro
 * Compatible GLPI 11 — CREATE TABLE directo con doQueryOrDie
 */

function plugin_ticketfuturo_install() {
    global $DB;

    $charset   = DBConnection::getDefaultCharset();
    $collation = DBConnection::getDefaultCollation();

    $DB->doQueryOrDie("
        CREATE TABLE IF NOT EXISTS `glpi_plugin_ticketfuturo_scheduledtickets` (
            `id`                 int unsigned      NOT NULL AUTO_INCREMENT,
            `name`               varchar(255)      NOT NULL DEFAULT '',
            `content`            longtext          DEFAULT NULL,
            `scheduled_date`     datetime          NOT NULL,
            `status`             tinyint           NOT NULL DEFAULT 0,
            `tickets_id`         int               NOT NULL DEFAULT 0,
            `type`               int               NOT NULL DEFAULT 1,
            `itilcategories_id`  int               NOT NULL DEFAULT 0,
            `users_id_assign`    int               NOT NULL DEFAULT 0,
            `groups_id_assign`   int               NOT NULL DEFAULT 0,
            `users_id_requester` int               NOT NULL DEFAULT 0,
            `priority`           int               NOT NULL DEFAULT 3,
            `entities_id`        int               NOT NULL DEFAULT 0,
            `users_id_creator`   int               NOT NULL DEFAULT 0,
            `date_creation`      datetime          DEFAULT NULL,
            `date_mod`           datetime          DEFAULT NULL,
            PRIMARY KEY (`id`),
            KEY `scheduled_date` (`scheduled_date`),
            KEY `status`         (`status`),
            KEY `entities_id`    (`entities_id`)
        ) ENGINE=InnoDB
          DEFAULT CHARSET={$charset}
          COLLATE={$collation}
    ", "Error al crear tabla glpi_plugin_ticketfuturo_scheduledtickets");

    // Registrar derechos en perfiles
    include_once(GLPI_ROOT . '/plugins/ticketfuturo/inc/profile.class.php');
    PluginTicketfuturoProfile::initProfile();
    if (isset($_SESSION['glpiactiveprofile']['id'])) {
        PluginTicketfuturoProfile::createFirstAccess($_SESSION['glpiactiveprofile']['id']);
    }

    // Registrar tarea cron
    CronTask::register(
        'PluginTicketfuturoScheduledTicket',
        'CreateScheduledTickets',
        HOUR_TIMESTAMP,
        [
            'comment' => 'Crear tickets futuros programados automaticamente',
            'mode'    => CronTask::MODE_EXTERNAL,
        ]
    );

    return true;
}

function plugin_ticketfuturo_uninstall() {
    global $DB;

    $DB->doQueryOrDie(
        "DROP TABLE IF EXISTS `glpi_plugin_ticketfuturo_scheduledtickets`",
        "Error al eliminar tabla ticketfuturo"
    );

    $profileRight = new ProfileRight();
    $profileRight->deleteByCriteria(['name' => 'plugin_ticketfuturo']);

    $cron = new CronTask();
    $cron->deleteByCriteria(['itemtype' => 'PluginTicketfuturoScheduledTicket']);

    return true;
}
