<?php
/**
 * Formulario de ticket futuro
 */

include('../../../inc/includes.php');

Session::checkRight('plugin_ticketfuturo', READ);

$item = new PluginTicketfuturoScheduledTicket();

if (isset($_POST['add'])) {
    Session::checkRight('plugin_ticketfuturo', CREATE);
    $item->check(-1, CREATE, $_POST);
    $newID = $item->add($_POST);
    Html::back();

} elseif (isset($_POST['update'])) {
    Session::checkRight('plugin_ticketfuturo', UPDATE);
    $item->check($_POST['id'], UPDATE, $_POST);
    $item->update($_POST);
    Html::back();

} elseif (isset($_POST['delete'])) {
    Session::checkRight('plugin_ticketfuturo', DELETE);
    $item->check($_POST['id'], DELETE, $_POST);
    $item->delete($_POST);
    Html::redirect(Plugin::getWebDir('ticketfuturo') . '/front/scheduledticket.php');

} elseif (isset($_POST['cancel'])) {
    Session::checkRight('plugin_ticketfuturo', UPDATE);
    $item->getFromDB($_POST['id']);
    if ($item->fields['status'] == 0) {
        $item->cancelScheduledTicket($_POST['id']);
        Session::addMessageAfterRedirect(__('Ticket futuro cancelado correctamente.', 'ticketfuturo'), true, INFO);
    }
    Html::back();

} else {
    $ID = $_GET['id'] ?? -1;

    Html::header(
        __('Ticket Futuro', 'ticketfuturo'),
        $_SERVER['PHP_SELF'],
        'admin',
        'PluginTicketfuturoScheduledTicket'
    );

    $item->display(['id' => $ID]);

    Html::footer();
}
