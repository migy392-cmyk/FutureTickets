<?php
include('../../../inc/includes.php');

Session::checkRight('plugin_ticketfuturo', READ);

Html::header(
    'Tickets Futuros',
    $_SERVER['PHP_SELF'],
    'admin',
    'PluginTicketfuturoScheduledTicket'
);

// Botón añadir manual para GLPI 11
if (PluginTicketfuturoScheduledTicket::canCreate()) {
    echo "<div class='container-fluid mb-3'>";
    echo "<a href='" . Plugin::getWebDir('ticketfuturo') . "/front/scheduledticket.form.php' class='btn btn-primary'>";
    echo "<i class='ti ti-plus me-1'></i>Añadir ticket futuro";
    echo "</a>";
    echo "</div>";
}

Search::show('PluginTicketfuturoScheduledTicket');

Html::footer();
