<?php
define('PLUGIN_EBRORRHH_VERSION', '2.0.0');
define('PLUGIN_EBRORRHH_MIN_GLPI', '11.0.0');
define('PLUGIN_EBRORRHH_MAX_GLPI', '11.99.99');

// Nombres de categorías RRHH (ajusta si cambian)
define('EBRORRHH_CAT_ALTAS',         'Altas');
define('EBRORRHH_CAT_BAJAS',         'Bajas');
define('EBRORRHH_CAT_MODIFICACIONES','Modificaciones');

function plugin_init_ebrorrhh() {
    global $PLUGIN_HOOKS;
    $PLUGIN_HOOKS['csrf_compliant']['ebrorrhh'] = true;

    Plugin::registerClass('PluginEbrorrhHPanel');
    Plugin::registerClass('PluginEbrorrhHTemplate');
    Plugin::registerClass('PluginEbrorrhHTask');

    // Tab dentro del ticket
    $PLUGIN_HOOKS['add_tabs']['ebrorrhh'] = [
        'Ticket' => 'PluginEbrorrhHPanel',
    ];

    // Menú administración
    if (Session::haveRight('config', UPDATE)) {
        $PLUGIN_HOOKS['menu_toadd']['ebrorrhh'] = [
            'admin' => 'PluginEbrorrhHTemplate',
        ];
    }
}

function plugin_version_ebrorrhh() {
    return [
        'name'         => 'Ebro RRHH',
        'version'      => PLUGIN_EBRORRHH_VERSION,
        'author'       => 'Ebro',
        'license'      => 'GPL v2+',
        'homepage'     => '',
        'requirements' => [
            'glpi' => ['min' => PLUGIN_EBRORRHH_MIN_GLPI, 'max' => PLUGIN_EBRORRHH_MAX_GLPI],
            'php'  => ['min' => '8.1'],
        ],
    ];
}

function plugin_ebrorrhh_check_prerequisites() {
    if (!defined('GLPI_VERSION')) return false;
    if (version_compare(GLPI_VERSION, PLUGIN_EBRORRHH_MIN_GLPI, 'lt')) {
        echo 'Requiere GLPI >= ' . PLUGIN_EBRORRHH_MIN_GLPI;
        return false;
    }
    return true;
}

function plugin_ebrorrhh_check_config() { return true; }
