<?php
function plugin_ebrorrhh_install() {
    global $DB;
    $charset   = DBConnection::getDefaultCharset();
    $collation = DBConnection::getDefaultCollation();

    // Plantillas de tareas por tipo RRHH
    $DB->doQueryOrDie("
        CREATE TABLE IF NOT EXISTS `glpi_plugin_ebrorrhh_templates` (
            `id`           int unsigned NOT NULL AUTO_INCREMENT,
            `name`         varchar(255) NOT NULL DEFAULT '',
            `rrhh_type`    varchar(50)  NOT NULL DEFAULT '' COMMENT 'altas|bajas|modificaciones',
            `description`  text DEFAULT NULL,
            `assigned_to`  varchar(255) NOT NULL DEFAULT 'IT',
            `rank`         int NOT NULL DEFAULT 0,
            `active`       tinyint NOT NULL DEFAULT 1,
            `date_creation`datetime DEFAULT NULL,
            PRIMARY KEY (`id`),
            KEY `rrhh_type` (`rrhh_type`)
        ) ENGINE=InnoDB DEFAULT CHARSET={$charset} COLLATE={$collation}
    ", "Error creando tabla templates");

    // Tareas de cada ticket RRHH
    $DB->doQueryOrDie("
        CREATE TABLE IF NOT EXISTS `glpi_plugin_ebrorrhh_tasks` (
            `id`            int unsigned NOT NULL AUTO_INCREMENT,
            `tickets_id`    int NOT NULL DEFAULT 0,
            `templates_id`  int unsigned NOT NULL DEFAULT 0 COMMENT '0=tarea manual',
            `name`          varchar(255) NOT NULL DEFAULT '',
            `description`   text DEFAULT NULL,
            `assigned_to`   varchar(255) NOT NULL DEFAULT 'IT',
            `status`        tinyint NOT NULL DEFAULT 0 COMMENT '0=Pendiente,1=En curso,2=Completado',
            `users_id_done` int NOT NULL DEFAULT 0,
            `date_done`     datetime DEFAULT NULL,
            `date_creation` datetime DEFAULT NULL,
            PRIMARY KEY (`id`),
            KEY `tickets_id` (`tickets_id`)
        ) ENGINE=InnoDB DEFAULT CHARSET={$charset} COLLATE={$collation}
    ", "Error creando tabla tasks");

    // Insertar plantillas por defecto
    $now = date('Y-m-d H:i:s');
    $defaultTemplates = [
        // ALTAS
        ['Crear cuenta Active Directory y email corporativo', 'altas', 'Crear usuario en AD, asignar contraseña inicial y configurar email corporativo.', 'IT', 1],
        ['Asignar y preparar equipo informático', 'altas', 'Seleccionar equipo del inventario, instalar SO y configurar según perfil del puesto.', 'IT', 2],
        ['Asignar teléfono móvil', 'altas', 'Asignar terminal móvil, configurar email y VPN si aplica.', 'IT', 3],
        ['Instalar software específico del puesto', 'altas', 'Instalar aplicaciones según departamento y puesto de trabajo.', 'IT', 4],
        ['Dar acceso a ERP y aplicaciones corporativas', 'altas', 'Crear usuario en ERP, dar permisos según rol y departamento.', 'IT', 5],
        ['Preparar y entregar documentación de bienvenida', 'altas', 'Entregar manual de usuario, política IT y documentación de accesos.', 'RRHH', 6],
        // BAJAS
        ['Recoger equipo informático y móvil', 'bajas', 'Recuperar portátil, móvil, periféricos y accesorios corporativos.', 'IT', 1],
        ['Desactivar cuenta Active Directory y email', 'bajas', 'Deshabilitar cuenta AD, redirigir email y revocar licencias.', 'IT', 2],
        ['Revocar accesos a ERP y aplicaciones', 'bajas', 'Eliminar o deshabilitar usuario en todas las aplicaciones corporativas.', 'IT', 3],
        ['Gestionar documentación de baja', 'bajas', 'Preparar finiquito, certificado de empresa y documentación de salida.', 'RRHH', 4],
        // MODIFICACIONES
        ['Actualizar permisos en Active Directory', 'modificaciones', 'Modificar grupos, permisos y unidad organizativa según nuevo puesto.', 'IT', 1],
        ['Actualizar accesos a ERP según nuevo rol', 'modificaciones', 'Ajustar perfiles y permisos en ERP y aplicaciones corporativas.', 'IT', 2],
        ['Revisar y reasignar equipo si aplica', 'modificaciones', 'Evaluar si el nuevo puesto requiere diferente equipo o periféricos.', 'IT', 3],
        ['Actualizar documentación interna', 'modificaciones', 'Actualizar ficha del empleado, organigrama y documentación HR.', 'RRHH', 4],
    ];

    foreach ($defaultTemplates as $t) {
        if (!countElementsInTable('glpi_plugin_ebrorrhh_templates', ['name' => $t[0], 'rrhh_type' => $t[1]])) {
            $DB->insert('glpi_plugin_ebrorrhh_templates', [
                'name'          => $t[0],
                'rrhh_type'     => $t[1],
                'description'   => $t[2],
                'assigned_to'   => $t[3],
                'rank'          => $t[4],
                'active'        => 1,
                'date_creation' => $now,
            ]);
        }
    }

    return true;
}

function plugin_ebrorrhh_uninstall() {
    global $DB;
    $DB->doQueryOrDie("DROP TABLE IF EXISTS `glpi_plugin_ebrorrhh_tasks`",     "Error");
    $DB->doQueryOrDie("DROP TABLE IF EXISTS `glpi_plugin_ebrorrhh_templates`", "Error");
    return true;
}
