<?php
if (!defined('GLPI_ROOT')) die("No direct access");

class PluginEbrorrhHTemplate extends CommonDBTM {
    static $rightname = 'config';

    public static function getTypeName($nb = 0) { return 'Plantillas RRHH'; }
    public static function getMenuName()         { return 'Ebro RRHH'; }

    public static function getMenuContent() {
        $menu = [];
        if (Session::haveRight('config', UPDATE)) {
            $menu['title'] = 'Ebro RRHH';
            $menu['page']  = Plugin::getWebDir('ebrorrhh') . '/front/template.php';
            $menu['icon']  = 'ti ti-users';
            $menu['options']['template']['title']           = 'Plantillas de tareas';
            $menu['options']['template']['page']            = Plugin::getWebDir('ebrorrhh') . '/front/template.php';
            $menu['options']['template']['links']['search'] = Plugin::getWebDir('ebrorrhh') . '/front/template.php';
            $menu['options']['template']['links']['add']    = Plugin::getWebDir('ebrorrhh') . '/front/template.form.php';
        }
        return $menu;
    }

    public static function getFormURL($full = true)   { return Plugin::getWebDir('ebrorrhh', $full) . '/front/template.form.php'; }
    public static function getSearchURL($full = true) { return Plugin::getWebDir('ebrorrhh', $full) . '/front/template.php'; }

    public function prepareInputForAdd($input) {
        $input['date_creation'] = date('Y-m-d H:i:s');
        $input['active']        = isset($input['active']) ? 1 : 0;
        return $input;
    }

    public function prepareInputForUpdate($input) {
        $input['active'] = isset($input['active']) ? 1 : 0;
        return $input;
    }

    public function showForm($ID, $options = []) {
        $this->initForm($ID, $options);
        $isNew = ($ID <= 0);
        $item  = $this;

        echo "<div class='container-fluid mt-3'>";
        echo "<form method='POST' action='" . Plugin::getWebDir('ebrorrhh') . "/front/template.form.php'>";
        echo Html::hidden('_glpi_csrf_token', ['value' => Session::getNewCSRFToken()]);
        if (!$isNew) echo "<input type='hidden' name='id' value='{$ID}'>";

        echo "<div class='row g-3'>";

        echo "<div class='col-md-6'>";
        echo "<label class='form-label fw-bold'>Nombre de la tarea <span class='text-danger'>*</span></label>";
        echo "<input type='text' class='form-control' name='name' value='" . htmlspecialchars($item->fields['name'] ?? '') . "' required autocomplete='off'>";
        echo "</div>";

        echo "<div class='col-md-3'>";
        echo "<label class='form-label fw-bold'>Tipo de proceso <span class='text-danger'>*</span></label>";
        echo "<select class='form-select' name='rrhh_type' required>";
        foreach (['altas' => 'Altas', 'bajas' => 'Bajas', 'modificaciones' => 'Modificaciones'] as $v => $l) {
            $sel = (($item->fields['rrhh_type'] ?? '') == $v) ? 'selected' : '';
            echo "<option value='{$v}' {$sel}>{$l}</option>";
        }
        echo "</select></div>";

        echo "<div class='col-md-2'>";
        echo "<label class='form-label fw-bold'>Asignado a</label>";
        echo "<input type='text' class='form-control' name='assigned_to' value='" . htmlspecialchars($item->fields['assigned_to'] ?? 'IT') . "' autocomplete='off'>";
        echo "</div>";

        echo "<div class='col-md-1'>";
        echo "<label class='form-label fw-bold'>Orden</label>";
        echo "<input type='number' class='form-control' name='rank' value='" . ($item->fields['rank'] ?? 0) . "' min='0'>";
        echo "</div>";

        echo "<div class='col-12'>";
        echo "<label class='form-label fw-bold'>Descripción</label>";
        echo "<textarea class='form-control' name='description' rows='3'>" . htmlspecialchars($item->fields['description'] ?? '') . "</textarea>";
        echo "</div>";

        echo "<div class='col-12'>";
        echo "<div class='form-check form-switch'>";
        $checked = ($item->fields['active'] ?? 1) ? 'checked' : '';
        echo "<input class='form-check-input' type='checkbox' name='active' id='active' {$checked}>";
        echo "<label class='form-check-label' for='active'>Plantilla activa</label>";
        echo "</div></div>";

        echo "</div>"; // row

        echo "<div class='d-flex gap-2 mt-3'>";
        if ($isNew) {
            echo "<button type='submit' name='add' class='btn btn-primary'><i class='ti ti-plus me-1'></i>Crear plantilla</button>";
        } else {
            echo "<button type='submit' name='update' class='btn btn-primary'><i class='ti ti-device-floppy me-1'></i>Guardar</button>";
            echo "<button type='submit' name='delete' class='btn btn-outline-danger' onclick=\"return confirm('¿Eliminar esta plantilla?')\">";
            echo "<i class='ti ti-trash me-1'></i>Eliminar</button>";
        }
        echo "<a href='" . Plugin::getWebDir('ebrorrhh') . "/front/template.php' class='btn btn-outline-secondary'>Volver</a>";
        echo "</div>";
        echo "</form></div>";
        return true;
    }

    public function rawSearchOptions() {
        $tab = [];
        $tab[] = ['id' => 'common', 'name' => self::getTypeName()];
        $tab[] = ['id' => '1', 'table' => $this->getTable(), 'field' => 'name',      'name' => 'Tarea',   'datatype' => 'itemlink'];
        $tab[] = ['id' => '2', 'table' => $this->getTable(), 'field' => 'rrhh_type', 'name' => 'Tipo',    'datatype' => 'string'];
        $tab[] = ['id' => '3', 'table' => $this->getTable(), 'field' => 'active',    'name' => 'Activa',  'datatype' => 'bool'];
        $tab[] = ['id' => '4', 'table' => $this->getTable(), 'field' => 'rank',      'name' => 'Orden',   'datatype' => 'integer'];
        return $tab;
    }
}
