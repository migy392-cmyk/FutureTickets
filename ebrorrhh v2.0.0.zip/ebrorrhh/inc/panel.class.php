<?php
if (!defined('GLPI_ROOT')) die("No direct access");

class PluginEbrorrhHPanel extends CommonDBTM {
    static $rightname = 'ticket';

    public static function getTypeName($nb = 0) { return 'Panel RRHH'; }

    /**
     * Detecta si un ticket es de RRHH por su categoría
     */
    public static function getRRHHType(Ticket $ticket): ?string {
        global $DB;
        $cat_id = $ticket->fields['itilcategories_id'] ?? 0;
        if (!$cat_id) return null;

        $cat = $DB->request([
            'SELECT' => ['id', 'name', 'completename'],
            'FROM'   => 'glpi_itilcategories',
            'WHERE'  => ['id' => $cat_id],
        ])->current();

        if (!$cat) return null;

        $name = strtolower($cat['completename']);
        if (str_contains($name, 'alta'))         return 'altas';
        if (str_contains($name, 'baja'))         return 'bajas';
        if (str_contains($name, 'modificacion')) return 'modificaciones';

        return null;
    }

    public function getTabNameForItem(CommonGLPI $item, $withtemplate = 0) {
        if (!($item instanceof Ticket)) return false;
        $type = self::getRRHHType($item);
        if (!$type) return false;

        $total    = countElementsInTable('glpi_plugin_ebrorrhh_tasks', ['tickets_id' => $item->fields['id']]);
        $done     = countElementsInTable('glpi_plugin_ebrorrhh_tasks', ['tickets_id' => $item->fields['id'], 'status' => 2]);
        $icon     = $total > 0 && $done == $total ? '✅' : '📋';
        $progress = $total > 0 ? " ({$done}/{$total})" : '';

        return "{$icon} RRHH{$progress}";
    }

    public static function displayTabContentForItem(CommonGLPI $item, $tabnum = 1, $withtemplate = 0) {
        if ($item instanceof Ticket) {
            self::showPanel($item);
        }
        return true;
    }

    public static function showPanel(Ticket $ticket) {
        global $DB, $CFG_GLPI;

        $tickets_id = $ticket->fields['id'];
        $rrhhType   = self::getRRHHType($ticket);
        if (!$rrhhType) return;

        $typeLabels = ['altas' => 'Alta de empleado', 'bajas' => 'Baja de empleado', 'modificaciones' => 'Modificación'];
        $typeColors = ['altas' => 'success', 'bajas' => 'danger', 'modificaciones' => 'warning'];
        $typeLabel  = $typeLabels[$rrhhType];
        $typeColor  = $typeColors[$rrhhType];

        // Estadísticas
        $total = countElementsInTable('glpi_plugin_ebrorrhh_tasks', ['tickets_id' => $tickets_id]);
        $done  = countElementsInTable('glpi_plugin_ebrorrhh_tasks', ['tickets_id' => $tickets_id, 'status' => 2]);
        $pct   = $total > 0 ? round($done / $total * 100) : 0;

        $isClosed = in_array($ticket->fields['status'], [Ticket::SOLVED, Ticket::CLOSED]);

        echo "<div class='container-fluid mt-3' id='ebrorrhh-panel'>";

        // Header
        echo "<div class='d-flex align-items-center gap-3 mb-3'>";
        echo "<span class='badge bg-{$typeColor} fs-6 px-3 py-2'>{$typeLabel}</span>";
        if ($total > 0) {
            $barColor = $pct == 100 ? 'bg-success' : 'bg-primary';
            echo "<div class='flex-grow-1'>";
            echo "<div class='d-flex justify-content-between mb-1'><small class='text-muted'>Progreso de tareas</small><small class='fw-bold'>{$done}/{$total} completadas ({$pct}%)</small></div>";
            echo "<div class='progress' style='height:8px'><div class='progress-bar {$barColor}' style='width:{$pct}%'></div></div>";
            echo "</div>";
        }
        echo "</div>";

        // Inicializar tareas desde plantillas si es la primera vez
        if ($total == 0 && !$isClosed) {
            echo "<div class='alert alert-info d-flex align-items-center gap-3'>";
            echo "<i class='ti ti-info-circle fs-4'></i>";
            echo "<div>No hay tareas aún. ";
            echo "<form method='POST' action='" . Plugin::getWebDir('ebrorrhh') . "/ajax/init_tasks.php' style='display:inline'>";
            echo Html::hidden('_glpi_csrf_token', ['value' => Session::getNewCSRFToken()]);
            echo "<input type='hidden' name='tickets_id' value='{$tickets_id}'>";
            echo "<input type='hidden' name='rrhh_type' value='{$rrhhType}'>";
            echo "<button type='submit' class='btn btn-primary btn-sm'><i class='ti ti-wand me-1'></i>Cargar plantillas de {$typeLabel}</button>";
            echo "</form></div></div>";
        }

        // Lista de tareas
        if ($total > 0) {
            $tasks = $DB->request([
                'FROM'  => 'glpi_plugin_ebrorrhh_tasks',
                'WHERE' => ['tickets_id' => $tickets_id],
                'ORDER' => ['status ASC', 'date_creation ASC'],
            ]);

            $statusLabels = ['Pendiente', 'En curso', 'Completado'];
            $statusColors = ['secondary', 'primary', 'success'];
            $statusIcons  = ['ti ti-clock', 'ti ti-loader', 'ti ti-circle-check'];

            echo "<div class='row g-2 mb-3'>";
            foreach ($tasks as $task) {
                $st      = (int)$task['status'];
                $isDone  = $st == 2;
                $border  = $isDone ? 'border-success' : ($st == 1 ? 'border-primary' : '');

                echo "<div class='col-12'>";
                echo "<div class='card {$border}' style='border-left: 4px solid " . ($isDone ? '#2e7d32' : ($st == 1 ? '#1565c0' : '#9e9e9e')) . " !important'>";
                echo "<div class='card-body p-3'>";
                echo "<div class='d-flex align-items-start gap-3'>";

                // Icono estado
                echo "<i class='{$statusIcons[$st]} mt-1 text-{$statusColors[$st]}' style='font-size:1.2rem'></i>";

                // Contenido
                echo "<div class='flex-grow-1'>";
                echo "<div class='fw-bold " . ($isDone ? 'text-decoration-line-through text-muted' : '') . "'>" . htmlspecialchars($task['name']) . "</div>";
                if ($task['description']) {
                    echo "<div class='text-muted small mt-1'>" . htmlspecialchars($task['description']) . "</div>";
                }
                echo "<div class='mt-1'>";
                echo "<span class='badge bg-{$statusColors[$st]}'>{$statusLabels[$st]}</span> ";
                echo "<span class='badge bg-light text-dark'><i class='ti ti-user me-1'></i>" . htmlspecialchars($task['assigned_to']) . "</span>";
                if ($isDone && $task['date_done']) {
                    echo " <span class='text-muted small'>Completado: " . date('d/m/Y H:i', strtotime($task['date_done'])) . "</span>";
                }
                echo "</div></div>";

                // Acciones
                if (!$isClosed) {
                    echo "<div class='d-flex gap-1 ms-auto'>";
                    if ($st == 0) {
                        echo "<form method='POST' action='" . Plugin::getWebDir('ebrorrhh') . "/ajax/task_action.php'>";
                        echo Html::hidden('_glpi_csrf_token', ['value' => Session::getNewCSRFToken()]);
                        echo "<input type='hidden' name='task_id' value='{$task['id']}'>";
                        echo "<input type='hidden' name='tickets_id' value='{$tickets_id}'>";
                        echo "<button type='submit' name='action' value='start' class='btn btn-sm btn-outline-primary' title='Iniciar'><i class='ti ti-player-play'></i></button>";
                        echo "</form>";
                    }
                    if ($st < 2) {
                        echo "<form method='POST' action='" . Plugin::getWebDir('ebrorrhh') . "/ajax/task_action.php'>";
                        echo Html::hidden('_glpi_csrf_token', ['value' => Session::getNewCSRFToken()]);
                        echo "<input type='hidden' name='task_id' value='{$task['id']}'>";
                        echo "<input type='hidden' name='tickets_id' value='{$tickets_id}'>";
                        echo "<button type='submit' name='action' value='done' class='btn btn-sm btn-outline-success' title='Completar'><i class='ti ti-check'></i></button>";
                        echo "</form>";
                    }
                    echo "<form method='POST' action='" . Plugin::getWebDir('ebrorrhh') . "/ajax/task_action.php'>";
                    echo Html::hidden('_glpi_csrf_token', ['value' => Session::getNewCSRFToken()]);
                    echo "<input type='hidden' name='task_id' value='{$task['id']}'>";
                    echo "<input type='hidden' name='tickets_id' value='{$tickets_id}'>";
                    echo "<button type='submit' name='action' value='delete' class='btn btn-sm btn-outline-danger' title='Eliminar' onclick=\"return confirm('¿Eliminar esta tarea?')\">";
                    echo "<i class='ti ti-trash'></i></button>";
                    echo "</form>";
                    echo "</div>";
                }

                echo "</div></div></div></div>";
            }
            echo "</div>"; // row
        }

        // Añadir tarea manual
        if (!$isClosed) {
            echo "<hr>";
            echo "<h6 class='mb-2'><i class='ti ti-plus me-2'></i>Añadir tarea</h6>";
            echo "<form method='POST' action='" . Plugin::getWebDir('ebrorrhh') . "/ajax/add_task.php'>";
            echo Html::hidden('_glpi_csrf_token', ['value' => Session::getNewCSRFToken()]);
            echo "<input type='hidden' name='tickets_id' value='{$tickets_id}'>";
            echo "<div class='row g-2'>";
            echo "<div class='col-md-5'>";
            echo "<input type='text' class='form-control form-control-sm' name='name' placeholder='Nombre de la tarea *' required autocomplete='off'>";
            echo "</div>";
            echo "<div class='col-md-3'>";
            echo "<input type='text' class='form-control form-control-sm' name='description' placeholder='Descripción (opcional)' autocomplete='off'>";
            echo "</div>";
            echo "<div class='col-md-2'>";
            echo "<input type='text' class='form-control form-control-sm' name='assigned_to' placeholder='Asignado a' value='IT' autocomplete='off'>";
            echo "</div>";
            echo "<div class='col-md-2'>";
            echo "<button type='submit' class='btn btn-success btn-sm w-100'><i class='ti ti-plus me-1'></i>Añadir</button>";
            echo "</div>";
            echo "</div></form>";

            // Añadir desde plantilla
            $templates = $DB->request([
                'FROM'  => 'glpi_plugin_ebrorrhh_templates',
                'WHERE' => ['rrhh_type' => $rrhhType, 'active' => 1],
                'ORDER' => ['rank ASC'],
            ]);
            $tplList = iterator_to_array($templates);

            if (!empty($tplList)) {
                echo "<div class='mt-2'>";
                echo "<form method='POST' action='" . Plugin::getWebDir('ebrorrhh') . "/ajax/add_task.php'>";
                echo Html::hidden('_glpi_csrf_token', ['value' => Session::getNewCSRFToken()]);
                echo "<input type='hidden' name='tickets_id' value='{$tickets_id}'>";
                echo "<div class='d-flex gap-2 align-items-center'>";
                echo "<select class='form-select form-select-sm' name='templates_id' style='max-width:400px'>";
                echo "<option value=''>— Añadir desde plantilla —</option>";
                foreach ($tplList as $tpl) {
                    echo "<option value='{$tpl['id']}'>" . htmlspecialchars($tpl['name']) . "</option>";
                }
                echo "</select>";
                echo "<button type='submit' class='btn btn-outline-primary btn-sm'><i class='ti ti-template me-1'></i>Añadir plantilla</button>";
                echo "</div></form></div>";
            }
        }

        echo "</div>"; // container
    }
}
