<?php
include('../../../inc/includes.php');
Session::checkRight('config', UPDATE);
Html::header('Ebro RRHH — Plantillas', $_SERVER['PHP_SELF'], 'admin', 'PluginEbrorrhHTemplate');
echo "<div class='container-fluid mb-3'>";
echo "<a href='" . Plugin::getWebDir('ebrorrhh') . "/front/template.form.php' class='btn btn-primary'>";
echo "<i class='ti ti-plus me-1'></i>Nueva plantilla de tarea</a>";
echo "</div>";
Search::show('PluginEbrorrhHTemplate');
Html::footer();
