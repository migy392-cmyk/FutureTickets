<?php
include('../../../inc/includes.php');
Session::checkRight('config', UPDATE);
$item = new PluginEbrorrhHTemplate();
if (isset($_POST['add'])) {
    $item->check(-1, CREATE, $_POST);
    $newID = $item->add($_POST);
    Html::redirect(Plugin::getWebDir('ebrorrhh') . '/front/template.php');
} elseif (isset($_POST['update'])) {
    $item->check($_POST['id'], UPDATE, $_POST);
    $item->update($_POST);
    Session::addMessageAfterRedirect('Plantilla actualizada.', true, INFO);
    Html::back();
} elseif (isset($_POST['delete'])) {
    $item->check($_POST['id'], DELETE, $_POST);
    $item->delete($_POST);
    Html::redirect(Plugin::getWebDir('ebrorrhh') . '/front/template.php');
} else {
    $ID = $_GET['id'] ?? -1;
    Html::header('Plantilla RRHH', $_SERVER['PHP_SELF'], 'admin', 'PluginEbrorrhHTemplate');
    $item->display(['id' => $ID]);
    Html::footer();
}
