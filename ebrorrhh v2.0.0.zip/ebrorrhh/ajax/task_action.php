<?php
include('../../../inc/includes.php');
Session::checkLoginUser();
Session::checkCSRF($_POST);

global $DB;

$task_id    = (int)($_POST['task_id']    ?? 0);
$tickets_id = (int)($_POST['tickets_id'] ?? 0);
$action     = $_POST['action'] ?? '';

if (!$task_id) { Html::back(); exit; }

switch ($action) {
    case 'start':
        $DB->update('glpi_plugin_ebrorrhh_tasks',
            ['status' => 1],
            ['id' => $task_id]
        );
        break;
    case 'done':
        $DB->update('glpi_plugin_ebrorrhh_tasks', [
            'status'        => 2,
            'users_id_done' => Session::getLoginUserID(),
            'date_done'     => date('Y-m-d H:i:s'),
        ], ['id' => $task_id]);
        break;
    case 'delete':
        $DB->delete('glpi_plugin_ebrorrhh_tasks', ['id' => $task_id]);
        break;
}

Html::back();
