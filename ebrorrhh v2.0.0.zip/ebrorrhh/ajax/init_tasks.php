<?php
include('../../../inc/includes.php');
Session::checkLoginUser();
Session::checkCSRF($_POST);

global $DB;

$tickets_id = (int)($_POST['tickets_id'] ?? 0);
$rrhh_type  = $_POST['rrhh_type'] ?? '';

if (!$tickets_id || !$rrhh_type) { Html::back(); exit; }

// Cargar todas las plantillas activas del tipo
$templates = $DB->request([
    'FROM'  => 'glpi_plugin_ebrorrhh_templates',
    'WHERE' => ['rrhh_type' => $rrhh_type, 'active' => 1],
    'ORDER' => ['rank ASC'],
]);

foreach ($templates as $tpl) {
    // No duplicar si ya existe
    if (!countElementsInTable('glpi_plugin_ebrorrhh_tasks', ['tickets_id' => $tickets_id, 'templates_id' => $tpl['id']])) {
        $DB->insert('glpi_plugin_ebrorrhh_tasks', [
            'tickets_id'    => $tickets_id,
            'templates_id'  => $tpl['id'],
            'name'          => $tpl['name'],
            'description'   => $tpl['description'],
            'assigned_to'   => $tpl['assigned_to'],
            'status'        => 0,
            'date_creation' => date('Y-m-d H:i:s'),
        ]);
    }
}

Session::addMessageAfterRedirect('✅ Tareas cargadas desde plantillas.', true, INFO);
Html::back();
