<?php
include('../../../inc/includes.php');
Session::checkLoginUser();
Session::checkCSRF($_POST);

global $DB;

$tickets_id   = (int)($_POST['tickets_id']  ?? 0);
$templates_id = (int)($_POST['templates_id']?? 0);
$name         = trim($_POST['name'] ?? '');

if (!$tickets_id) { Html::back(); exit; }

if ($templates_id > 0) {
    // Añadir desde plantilla
    $tpl = $DB->request(['FROM' => 'glpi_plugin_ebrorrhh_templates', 'WHERE' => ['id' => $templates_id]])->current();
    if ($tpl) {
        $DB->insert('glpi_plugin_ebrorrhh_tasks', [
            'tickets_id'    => $tickets_id,
            'templates_id'  => $templates_id,
            'name'          => $tpl['name'],
            'description'   => $tpl['description'],
            'assigned_to'   => $tpl['assigned_to'],
            'status'        => 0,
            'date_creation' => date('Y-m-d H:i:s'),
        ]);
        Session::addMessageAfterRedirect('Tarea añadida desde plantilla.', true, INFO);
    }
} elseif ($name) {
    // Tarea manual
    $DB->insert('glpi_plugin_ebrorrhh_tasks', [
        'tickets_id'    => $tickets_id,
        'templates_id'  => 0,
        'name'          => $name,
        'description'   => $_POST['description'] ?? '',
        'assigned_to'   => $_POST['assigned_to'] ?? 'IT',
        'status'        => 0,
        'date_creation' => date('Y-m-d H:i:s'),
    ]);
    Session::addMessageAfterRedirect('Tarea añadida correctamente.', true, INFO);
}

Html::back();
