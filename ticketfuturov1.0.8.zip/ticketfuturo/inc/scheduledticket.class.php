<?php
/**
 * Clase principal PluginTicketfuturoScheduledTicket
 */

if (!defined('GLPI_ROOT')) {
    die("Sorry. You can't access this file directly");
}

class PluginTicketfuturoScheduledTicket extends CommonDBTM {

    static $rightname = 'plugin_ticketfuturo';

    public static function getTypeName($nb = 0) {
        return _n('Ticket Futuro', 'Tickets Futuros', $nb, 'ticketfuturo');
    }

    public static function getMenuName() {
        return __('Tickets Futuros', 'ticketfuturo');
    }

    public static function getMenuContent() {
        $menu = [];

        if (self::canView()) {
            $menu['title'] = self::getMenuName();
            $menu['page']  = Plugin::getWebDir('ticketfuturo') . '/front/scheduledticket.php';
            $menu['icon']  = 'ti ti-clock-plus';

            $menu['options']['scheduledticket']['title'] = self::getMenuName();
            $menu['options']['scheduledticket']['page']  = Plugin::getWebDir('ticketfuturo') . '/front/scheduledticket.php';
            $menu['options']['scheduledticket']['links']['search'] = Plugin::getWebDir('ticketfuturo') . '/front/scheduledticket.php';

            if (self::canCreate()) {
                $menu['options']['scheduledticket']['links']['add'] = Plugin::getWebDir('ticketfuturo') . '/front/scheduledticket.form.php';
            }
        }

        return $menu;
    }

    public static function getFormURL($full = true) {
        return Plugin::getWebDir('ticketfuturo', $full) . '/front/scheduledticket.form.php';
    }

    public static function getSearchURL($full = true) {
        return Plugin::getWebDir('ticketfuturo', $full) . '/front/scheduledticket.php';
    }

    public function defineTabs($options = []) {
        $ong = [];
        $this->addDefaultFormTab($ong);
        return $ong;
    }

    public function rawSearchOptions() {
        $tab = [];

        $tab[] = [
            'id'            => 'common',
            'name'          => self::getTypeName(1),
        ];

        $tab[] = [
            'id'            => '1',
            'table'         => $this->getTable(),
            'field'         => 'name',
            'name'          => __('Título', 'ticketfuturo'),
            'datatype'      => 'itemlink',
            'massiveaction' => false,
        ];

        $tab[] = [
            'id'            => '2',
            'table'         => $this->getTable(),
            'field'         => 'scheduled_date',
            'name'          => __('Fecha programada', 'ticketfuturo'),
            'datatype'      => 'datetime',
            'massiveaction' => false,
        ];

        $tab[] = [
            'id'            => '3',
            'table'         => $this->getTable(),
            'field'         => 'status',
            'name'          => __('Estado', 'ticketfuturo'),
            'datatype'      => 'specific',
            'massiveaction' => false,
        ];

        $tab[] = [
            'id'            => '4',
            'table'         => $this->getTable(),
            'field'         => 'priority',
            'name'          => __('Prioridad', 'ticketfuturo'),
            'datatype'      => 'specific',
            'massiveaction' => false,
        ];

        $tab[] = [
            'id'            => '5',
            'table'         => 'glpi_itilcategories',
            'field'         => 'completename',
            'name'          => __('Categoría', 'ticketfuturo'),
            'datatype'      => 'dropdown',
            'foreignkey'    => 'itilcategories_id',
        ];

        $tab[] = [
            'id'            => '6',
            'table'         => $this->getTable(),
            'field'         => 'type',
            'name'          => __('Tipo', 'ticketfuturo'),
            'datatype'      => 'specific',
        ];

        return $tab;
    }

    public static function getStatusName($status) {
        switch ($status) {
            case 0: return __('Pendiente', 'ticketfuturo');
            case 1: return __('Creado', 'ticketfuturo');
            case 2: return __('Cancelado', 'ticketfuturo');
            default: return __('Desconocido', 'ticketfuturo');
        }
    }

    public static function getStatusColor($status) {
        switch ($status) {
            case 0: return 'warning';
            case 1: return 'success';
            case 2: return 'danger';
            default: return 'secondary';
        }
    }

    public function showForm($ID, $options = []) {
        $this->initForm($ID, $options);
        TemplateRenderer::getInstance()->display('@ticketfuturo/scheduledticket.form.html.twig', [
            'item'   => $this,
            'params' => $options,
        ]);
        return true;
    }

    public function prepareInputForAdd($input) {
        $input['date_creation']  = date('Y-m-d H:i:s');
        $input['date_mod']       = date('Y-m-d H:i:s');
        $input['users_id_creator'] = Session::getLoginUserID();
        $input['entities_id']    = isset($input['entities_id']) ? $input['entities_id'] : $_SESSION['glpiactive_entity'];
        $input['status']         = 0;

        if (empty($input['scheduled_date'])) {
            Session::addMessageAfterRedirect(__('La fecha programada es obligatoria.', 'ticketfuturo'), false, ERROR);
            return false;
        }

        if (strtotime($input['scheduled_date']) <= time()) {
            Session::addMessageAfterRedirect(__('La fecha programada debe ser futura.', 'ticketfuturo'), false, ERROR);
            return false;
        }

        return $input;
    }

    public function prepareInputForUpdate($input) {
        $input['date_mod'] = date('Y-m-d H:i:s');
        return $input;
    }

    /**
     * Tarea cron para crear tickets cuando llega su fecha
     */
    public static function cronCreateScheduledTickets($task) {
        global $DB;

        $now = date('Y-m-d H:i:s');
        $created = 0;
        $errors  = 0;

        $iterator = $DB->request([
            'FROM'  => 'glpi_plugin_ticketfuturo_scheduledtickets',
            'WHERE' => [
                'status'         => 0,
                'scheduled_date' => ['<=', $now],
            ],
        ]);

        foreach ($iterator as $row) {
            $ticket = new Ticket();
            $input  = [
                'name'              => $row['name'],
                'content'           => $row['content'],
                'type'              => $row['type'],
                'itilcategories_id' => $row['itilcategories_id'],
                'priority'          => $row['priority'],
                'entities_id'       => $row['entities_id'],
                '_users_id_assign'  => $row['users_id_assign'],
                '_groups_id_assign' => $row['groups_id_assign'],
                '_users_id_requester' => $row['users_id_requester'] ?: Session::getLoginUserID(),
                'status'            => Ticket::INCOMING,
            ];

            $ticket_id = $ticket->add($input);

            $scheduled = new self();
            if ($ticket_id) {
                $scheduled->update([
                    'id'         => $row['id'],
                    'status'     => 1,
                    'tickets_id' => $ticket_id,
                    'date_mod'   => date('Y-m-d H:i:s'),
                ]);

                // Enviar notificación
                self::sendCreationNotification($row, $ticket_id);

                $created++;
                $task->addVolume(1);
                $task->log(sprintf('Ticket futuro ID %d creado como Ticket #%d', $row['id'], $ticket_id));
            } else {
                $errors++;
                $task->log(sprintf('Error al crear ticket futuro ID %d', $row['id']));
            }
        }

        return ($errors > 0) ? -1 : ($created > 0 ? 1 : 0);
    }

    public static function cronInfo($name) {
        return [
            'description' => __('Crear tickets programados cuando llegue su fecha', 'ticketfuturo'),
            'parameter'   => false,
        ];
    }

    protected static function sendCreationNotification($scheduledData, $ticket_id) {
        global $DB;

        // Obtener datos del creador
        $user = new User();
        if (!$user->getFromDB($scheduledData['users_id_creator'])) {
            return;
        }

        $email = $user->getDefaultEmail();
        if (empty($email)) {
            return;
        }

        $ticket = new Ticket();
        $ticket->getFromDB($ticket_id);

        $mmail = new GLPIMailer();
        $mmail->AddAddress($email, $user->getFriendlyName());
        $mmail->SetFrom(GLPI_NOREPLY_EMAIL ?? 'noreply@glpi.local');
        $mmail->Subject = sprintf(__('[GLPI] Ticket Futuro creado: %s (#%d)', 'ticketfuturo'), $scheduledData['name'], $ticket_id);
        $mmail->Body    = sprintf(
            __("El ticket futuro '%s' ha sido creado automáticamente.\n\nTicket ID: #%d\nFecha de creación: %s\n\nAccede a GLPI para ver el ticket.", 'ticketfuturo'),
            $scheduledData['name'],
            $ticket_id,
            date('d/m/Y H:i')
        );
        $mmail->IsHTML(false);
        $mmail->Send();
    }

    public static function canCancel($id) {
        $item = new self();
        $item->getFromDB($id);
        return ($item->fields['status'] == 0);
    }

    public function cancelScheduledTicket($id) {
        return $this->update([
            'id'       => $id,
            'status'   => 2,
            'date_mod' => date('Y-m-d H:i:s'),
        ]);
    }
}
